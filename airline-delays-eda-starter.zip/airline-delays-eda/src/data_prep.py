import pandas as pd

def read_dot_csv(path: str, usecols=None) -> pd.DataFrame:
    return pd.read_csv(path, low_memory=False, usecols=usecols)

def normalize_times(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    if "CRS_DEP_TIME" in out.columns:
        out["CRS_DEP_HOUR"] = (out["CRS_DEP_TIME"].astype(str).str.zfill(4).str[:2]).astype(int)
    if "CRS_ARR_TIME" in out.columns:
        out["CRS_ARR_HOUR"] = (out["CRS_ARR_TIME"].astype(str).str.zfill(4).str[:2]).astype(int)
    if "FL_DATE" in out.columns:
        out["FL_DATE"] = pd.to_datetime(out["FL_DATE"], errors="coerce")
        out["YEAR"] = out["FL_DATE"].dt.year
        out["MONTH"] = out["FL_DATE"].dt.month
        out["DAY"] = out["FL_DATE"].dt.day
        out["DOW"] = out["FL_DATE"].dt.dayofweek
    return out

def basic_clean(df: pd.DataFrame) -> pd.DataFrame:
    return df.dropna(axis=1, how="all").drop_duplicates()
