import os
import matplotlib.pyplot as plt
import pandas as pd

def save_counts_bar(df: pd.DataFrame, col: str, out_path: str, top_n=None):
    counts = df[col].value_counts(dropna=False)
    if top_n:
        counts = counts.head(top_n)
    ax = counts.sort_values(ascending=True).plot(kind="barh")
    ax.set_title(f"Count by {col}")
    ax.set_xlabel("Count")
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.savefig(out_path, dpi=150)
    plt.close()

def save_delay_by_hour(df: pd.DataFrame, hour_col: str, delay_col: str, out_path: str):
    grp = df.groupby(hour_col)[delay_col].mean().sort_index()
    ax = grp.plot(kind="line", marker="o")
    ax.set_title(f"Average {delay_col} by {hour_col}")
    ax.set_ylabel(f"Average {delay_col}")
    ax.set_xlabel(hour_col)
    plt.tight_layout()
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    plt.savefig(out_path, dpi=150)
    plt.close()
