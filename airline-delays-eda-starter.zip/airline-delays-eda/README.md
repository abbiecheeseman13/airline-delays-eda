# Airline Delays EDA with Weather Features

**Goal**  
Explore and clean a slice of the US DOT On-Time Performance data and produce visuals that explain when and where delays spike. This project is the first in a 4-project portfolio.

**What this repo shows**
- Data cleaning and tidy formatting
- Exploratory analysis and simple feature engineering
- Clear, labeled charts
- A short narrative of findings and next steps

**How to run**
1. Create a virtual env and install requirements.
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Place a CSV of US DOT On-Time Performance records in `data/raw/`.  
3. Open the notebook:
   ```bash
   jupyter notebook notebooks/01_eda.ipynb
   ```

**Findings template (fill this in)**
- Peak delays by hour and carrier:
- Airports with the highest average departure delay:
- Weather or seasonal effects observed:
- Notes for modeling in Project 2:

_Last updated: 2025-08-30_
