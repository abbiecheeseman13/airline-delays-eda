import pandas as pd
from src.data_prep import normalize_times

def test_normalize_times_hours():
    df = pd.DataFrame({"CRS_DEP_TIME": [5, 45, 123, 2359], "FL_DATE": ["2020-01-01"]*4})
    out = normalize_times(df)
    assert set([0,0,1,23]).issubset(set(out["CRS_DEP_HOUR"].unique()))
